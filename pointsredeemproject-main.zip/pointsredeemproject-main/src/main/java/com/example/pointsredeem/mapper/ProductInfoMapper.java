package com.example.pointsredeem.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.pointsredeem.model.ProductInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 商品信息表（积分兑换专用） Mapper 接口
 * </p>
 *
 * @author liya test
 * @since 2026-03-06
 */
public interface ProductInfoMapper extends BaseMapper<ProductInfo> {

    IPage<ProductInfo> productList(@Param("page") IPage page, @Param("product") ProductInfo productInfo);

}
