package com.example.pointsredeem.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.pointsredeem.model.system.SysUserRole;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liya test
 * @since 2023-03-22
 */
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {

}
