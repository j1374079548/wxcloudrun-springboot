package com.example.pointsredeem.mapper;

import com.example.pointsredeem.model.Address;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liya test
 * @since 2026-03-13
 */
public interface AddressMapper extends BaseMapper<Address> {

}
