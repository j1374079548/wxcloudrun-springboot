package com.example.pointsredeem.controller;


import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.additional.update.impl.UpdateChainWrapper;
import com.example.pointsredeem.common.ProductCodeGenerator;
import com.example.pointsredeem.common.aspect.ButtonPermission;
import com.example.pointsredeem.common.aspect.Log;
import com.example.pointsredeem.common.pojo.ResponseBo;
import com.example.pointsredeem.model.ProductInfo;
import com.example.pointsredeem.model.ShopCategory;
import com.example.pointsredeem.model.system.SysDictionary;
import com.example.pointsredeem.service.IProductInfoService;
import com.example.pointsredeem.service.IShopCategoryService;
import com.example.pointsredeem.service.system.ISysDictionaryService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 商品信息表（积分兑换专用） 前端控制器
 * </p>
 *
 * @author liya test
 * @since 2026-03-06
 */
@RestController
@RequestMapping("/product")
public class ProductInfoController {

    @Autowired
    private IProductInfoService productInfoService;

    @Autowired
    private IShopCategoryService shopCategoryService;

    @GetMapping("/page")
    public ResponseBo page(int pageNum, int pageSize, ProductInfo productInfo) {
        IPage<ProductInfo> productInfoIPage = productInfoService.productList(pageNum, pageSize, productInfo);
        return ResponseBo.ok(productInfoIPage);
    }

    @GetMapping("/view")
    public ResponseBo view(String id) {
        ProductInfo productInfo = productInfoService.getById(id);
        if(StringUtils.isNotBlank(productInfo.getProductCategoryId())){
            ShopCategory shopCategory = shopCategoryService.getById(productInfo.getProductCategoryId());
            if(shopCategory!=null){
                productInfo.setProductCategory(shopCategory.getShopCategoryName());

            }
        }
        return ResponseBo.ok(productInfo);
    }


    @GetMapping("/del")
    @Log(title = "删除商品")
    @ButtonPermission(perm = "product:del")
    public ResponseBo del(String id) {
        boolean remove = productInfoService.removeById(id);
        if(remove){
            return ResponseBo.ok();
        }
        return ResponseBo.error();

    }


    @PostMapping("/add")
    @Log(title = "添加商品")
    @ButtonPermission(perm = "product:add")
    public ResponseBo add(@RequestBody ProductInfo productInfo) {
        String productCode = ProductCodeGenerator.generateCode();
        productInfo.setProductCode(productCode);
        boolean save = productInfoService.save(productInfo);
        if(save){
            return ResponseBo.ok();
        }
        return ResponseBo.error();
    }

    @PostMapping("/edit")
    @Log(title = "修改商品")
    @ButtonPermission(perm = "product:edit")
    public ResponseBo edit(@RequestBody ProductInfo productInfo) {
        String productCode = ProductCodeGenerator.generateCode();
        productInfo.setProductCode(productCode);
        boolean update = productInfoService.updateById(productInfo);
        if(update){
            return ResponseBo.ok();
        }
        return ResponseBo.error();
    }


    /**
     * 上架、下架
     * @param id
     * @return
     */
    @GetMapping("/put")
    public ResponseBo put(String id,String saleStatus) {
        LambdaUpdateWrapper<ProductInfo> productInfoLambdaUpdateWrapper=new LambdaUpdateWrapper<>();
        productInfoLambdaUpdateWrapper.eq(ProductInfo::getId,id);
        productInfoLambdaUpdateWrapper.set(ProductInfo::getSaleStatus,saleStatus);
        boolean update = productInfoService.update(productInfoLambdaUpdateWrapper);
        if(update){
            return ResponseBo.ok();
        }
        return ResponseBo.error();
    }

}
