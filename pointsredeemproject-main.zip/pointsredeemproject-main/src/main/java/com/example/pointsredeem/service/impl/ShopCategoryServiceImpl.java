package com.example.pointsredeem.service.impl;

import com.example.pointsredeem.model.ShopCategory;
import com.example.pointsredeem.mapper.ShopCategoryMapper;
import com.example.pointsredeem.service.IShopCategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liya test
 * @since 2026-03-08
 */
@Service
public class ShopCategoryServiceImpl extends ServiceImpl<ShopCategoryMapper, ShopCategory> implements IShopCategoryService {

}
