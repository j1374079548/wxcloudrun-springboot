package com.example.pointsredeem.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.pointsredeem.common.aspect.ButtonPermission;
import com.example.pointsredeem.common.aspect.Log;
import com.example.pointsredeem.common.pojo.ResponseBo;
import com.example.pointsredeem.common.util.JwtUtil;
import com.example.pointsredeem.model.GivePoints;
import com.example.pointsredeem.model.Shop;
import com.example.pointsredeem.model.WxUser;
import com.example.pointsredeem.model.system.SysRole;
import com.example.pointsredeem.model.system.SysUser;
import com.example.pointsredeem.model.system.SysUserRole;
import com.example.pointsredeem.service.IGivePointsService;
import com.example.pointsredeem.service.IShopService;
import com.example.pointsredeem.service.IWxUserService;
import com.example.pointsredeem.service.system.ISysRoleService;
import com.example.pointsredeem.service.system.ISysUserRoleService;
import com.example.pointsredeem.service.system.ISysUserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author liya test
 * @since 2026-03-09
 */
@RestController
@RequestMapping("/givePoints")
public class GivePointsController {

    @Autowired
    private IGivePointsService givePointsService;

    @Autowired
    private IShopService  shopService;

    @Autowired
    private IWxUserService wxUserService;

    @Autowired
    private ISysUserService sysUserService;


    @GetMapping("/page")
    public ResponseBo page(int pageNum, int pageSize, GivePoints givePoints) {

        IPage<GivePoints> givePointsIPage = givePointsService.givePointsList(pageNum,pageSize,givePoints);

        return ResponseBo.ok(givePointsIPage);
    }

    @GetMapping("/view")
    public ResponseBo view(String id) {
        GivePoints givePoints = givePointsService.getById(id);

        return ResponseBo.ok(givePoints);
    }



    @PostMapping("/add")
    @Log(title = "添加积分发放")
    @ButtonPermission(perm = "givePoints:add")
    @Transactional
    public ResponseBo add(@RequestBody GivePoints givePoints) {

        if("1".equals(givePoints.getRoleType())){
            Shop shop = shopService.getById(givePoints.getShopId());
            LambdaUpdateWrapper<Shop> shopLambdaUpdateWrapper=new LambdaUpdateWrapper<>();
            shopLambdaUpdateWrapper.eq(Shop::getId,givePoints.getShopId());
            shopLambdaUpdateWrapper.set(Shop::getIntegral,shop.getIntegral()==null?givePoints.getIntegral():shop.getIntegral()+givePoints.getIntegral());
            shopService.update(shopLambdaUpdateWrapper);
        }else{
            SysUser sysUser = sysUserService.getById(JwtUtil.getCurrentUserId());
            Shop shop = shopService.getById(sysUser.getShopName());

            if(shop.getIntegral()==null||shop.getIntegral()==0){
                return ResponseBo.error("该管理员所属经销商暂无积分！");
            }else if(shop.getIntegral()<=givePoints.getIntegral()){
                return ResponseBo.error("该管理员所属经销商积分不足！");
            }

            LambdaUpdateWrapper<Shop> shopLambdaUpdateWrapper=new LambdaUpdateWrapper<>();
            shopLambdaUpdateWrapper.eq(Shop::getId,shop.getId());
            shopLambdaUpdateWrapper.set(Shop::getIntegral,shop.getIntegral()-givePoints.getIntegral());
            shopService.update(shopLambdaUpdateWrapper);


            WxUser wxUser = wxUserService.getById(givePoints.getShopId());
            LambdaUpdateWrapper<WxUser> wxUserLambdaUpdateWrapper=new LambdaUpdateWrapper<>();
            wxUserLambdaUpdateWrapper.eq(WxUser::getId,givePoints.getShopId());
            wxUserLambdaUpdateWrapper.set(WxUser::getIntegral,wxUser.getIntegral()==null?givePoints.getIntegral():wxUser.getIntegral()+givePoints.getIntegral());
            wxUserService.update(wxUserLambdaUpdateWrapper);
        }
        givePoints.setCreateBy(JwtUtil.getCurrentUserId());
        boolean save = givePointsService.save(givePoints);
        if(save){
            return ResponseBo.ok();
        }
        return ResponseBo.error("发放失败");
    }



}
