package com.example.pointsredeem.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.pointsredeem.common.aspect.ButtonPermission;
import com.example.pointsredeem.common.aspect.Log;
import com.example.pointsredeem.common.pojo.ResponseBo;
import com.example.pointsredeem.model.ShopCategory;
import com.example.pointsredeem.service.IShopCategoryService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author liya test
 * @since 2026-03-08
 */
@RestController
@RequestMapping("/category")
public class ShopCategoryController {

    @Autowired
    private IShopCategoryService shopCategoryService;

    @GetMapping("/page")
    public ResponseBo page(int pageNum, int pageSize, ShopCategory shopCategory) {
        IPage<ShopCategory> page=new Page<>(pageNum,pageSize);
        LambdaQueryWrapper<ShopCategory> shopLambdaQueryWrapper=new LambdaQueryWrapper<>();
        if (StringUtils.isNotBlank(shopCategory.getShopCategoryName())) {
            shopLambdaQueryWrapper.like(ShopCategory::getShopCategoryName,shopCategory.getShopCategoryName());
        }
        shopLambdaQueryWrapper.orderByDesc(ShopCategory::getCreateTime);
        IPage<ShopCategory> shopCategoryIPage = shopCategoryService.page(page, shopLambdaQueryWrapper);
        return ResponseBo.ok(shopCategoryIPage);
    }

    @GetMapping("/view")
    public ResponseBo view(String id) {
        ShopCategory shopCategory = shopCategoryService.getById(id);

        return ResponseBo.ok(shopCategory);
    }


    @GetMapping("/del")
    @Log(title = "删除商品分类")
    @ButtonPermission(perm = "category:del")
    public ResponseBo del(String id) {
        boolean remove = shopCategoryService.removeById(id);
        if(remove){
            return ResponseBo.ok();
        }
        return ResponseBo.error();

    }


    @PostMapping("/add")
    @Log(title = "添加商品分类")
    @ButtonPermission(perm = "category:add")
    public ResponseBo add(@RequestBody ShopCategory shopCategory) {

        boolean save = shopCategoryService.save(shopCategory);
        if(save){
            return ResponseBo.ok();
        }
        return ResponseBo.error();
    }

    @PostMapping("/edit")
    @Log(title = "修改商品分类")
    @ButtonPermission(perm = "category:edit")
    public ResponseBo edit(@RequestBody ShopCategory shopCategory) {

        boolean update = shopCategoryService.updateById(shopCategory);
        if(update){
            return ResponseBo.ok();
        }
        return ResponseBo.error();
    }


    @GetMapping("/list")
    public ResponseBo list() {
        List<ShopCategory> shopCategoryList = shopCategoryService.list();

        return ResponseBo.ok(shopCategoryList);
    }

}
