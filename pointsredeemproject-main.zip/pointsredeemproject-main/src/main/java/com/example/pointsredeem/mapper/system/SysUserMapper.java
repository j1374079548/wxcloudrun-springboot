package com.example.pointsredeem.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.pointsredeem.model.system.SysUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liya test
 * @since 2023-03-15
 */
public interface SysUserMapper extends BaseMapper<SysUser> {

    IPage<SysUser> userPage(@Param("page") IPage page,@Param("user") SysUser user);

    //导出
    List<SysUser> userList(@Param("user") SysUser user);

    String selectNameBatchIds(@Param("idList") String[] idList);
}
