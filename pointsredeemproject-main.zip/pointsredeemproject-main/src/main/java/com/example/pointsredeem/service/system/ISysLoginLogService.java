package com.example.pointsredeem.service.system;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.pointsredeem.model.system.SysLoginLog;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liya test
 * @since 2023-04-27
 */
public interface ISysLoginLogService extends IService<SysLoginLog> {

    IPage<SysLoginLog> getPage(int pageNum,int pageSize);

}
