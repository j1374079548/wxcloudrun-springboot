package com.example.pointsredeem.service;

import com.example.pointsredeem.model.Address;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liya test
 * @since 2026-03-13
 */
public interface IAddressService extends IService<Address> {

}
