package com.example.pointsredeem.service.system.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.pointsredeem.mapper.system.SysOperLogMapper;
import com.example.pointsredeem.model.system.SysOperLog;
import com.example.pointsredeem.service.system.ISysOperLogService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liya test
 * @since 2023-05-04
 */
@Service
public class SysOperLogServiceImpl extends ServiceImpl<SysOperLogMapper, SysOperLog> implements ISysOperLogService {

}
