package com.example.pointsredeem.service.impl;

import com.example.pointsredeem.model.WxUser;
import com.example.pointsredeem.mapper.WxUserMapper;
import com.example.pointsredeem.service.IWxUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liya test
 * @since 2026-03-08
 */
@Service
public class WxUserServiceImpl extends ServiceImpl<WxUserMapper, WxUser> implements IWxUserService {

}
