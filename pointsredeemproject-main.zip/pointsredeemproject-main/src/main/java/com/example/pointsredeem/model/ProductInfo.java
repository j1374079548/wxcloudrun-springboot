package com.example.pointsredeem.model;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 商品信息表（积分兑换专用）
 * </p>
 *
 * @author liya test
 * @since 2026-03-06
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
public class ProductInfo extends Model {

    private static final long serialVersionUID = 1L;

    /**
     * 商品主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 商品编码（唯一，如PROD_20260306001）
     */
    private String productCode;

    /**
     * 商品名称
     */
    private String productName;

    /**
     * 商品分类ID
     */
    private String productCategoryId;

    @TableField(exist = false)
    private String productCategory;

    /**
     * 商品主图URL
     */
    private String productImg;

    /**
     * 商品详情描述
     */
    private String productDesc;

    /**
     * 兑换所需积分（核心字段）
     */
    private Integer integralPrice;

    /**
     * 商品原价（元，非必须）
     */
    private BigDecimal originalPrice;

    /**
     * 可兑换库存（0表示无库存）
     */
    private Integer exchangeStock;

    /**
     * 总库存（用于统计）
     */
    private Integer totalStock;

    /**
     *
     */
    private String unit;

    /**
     * 上下架状态：1-上架 2-下架
     */
    private String saleStatus;


    /**
     * 兑换规则（JSON格式，如限购、使用条件）
     */
    private String exchangeRule;

    /**
     * 创建时间
     */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @TableField(value = "create_time",fill= FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @TableField(value = "update_time",fill= FieldFill.UPDATE)
    private LocalDateTime updateTime;

    /**
     * 扩展字段（JSON，存储定制化属性）
     */
    private String extInfo;


}
