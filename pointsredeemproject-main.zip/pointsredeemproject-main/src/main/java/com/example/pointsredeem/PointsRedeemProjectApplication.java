package com.example.pointsredeem;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication(exclude = SecurityAutoConfiguration.class)
@MapperScan("com.example.pointsredeem.mapper")
@EnableTransactionManagement
@ServletComponentScan
public class PointsRedeemProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(PointsRedeemProjectApplication.class, args);
    }

}
