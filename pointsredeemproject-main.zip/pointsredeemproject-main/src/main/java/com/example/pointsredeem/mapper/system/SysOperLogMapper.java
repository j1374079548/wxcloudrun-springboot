package com.example.pointsredeem.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.pointsredeem.model.system.SysOperLog;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liya test
 * @since 2023-05-04
 */
public interface SysOperLogMapper extends BaseMapper<SysOperLog> {

}
