package com.example.pointsredeem.service.system;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.pointsredeem.model.system.SysMenu;
import com.example.pointsredeem.model.system.SysUserRole;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liya test
 * @since 2023-03-22
 */
public interface ISysUserRoleService extends IService<SysUserRole> {

    public List<SysMenu> getMenu();

}
