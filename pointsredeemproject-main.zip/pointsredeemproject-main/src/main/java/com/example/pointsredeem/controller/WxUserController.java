package com.example.pointsredeem.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.pointsredeem.common.pojo.ResponseBo;
import com.example.pointsredeem.model.GivePoints;
import com.example.pointsredeem.model.WxUser;
import com.example.pointsredeem.service.IWxUserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author liya test
 * @since 2026-03-08
 */
@RestController
@RequestMapping("/wxUser")
public class WxUserController {

    @Autowired
    private IWxUserService wxUserService;


    @GetMapping("/page")
    public ResponseBo page(int pageNum, int pageSize, WxUser wxUser) {

        LambdaQueryWrapper<WxUser> wxUserLambdaQueryWrapper=new LambdaQueryWrapper<>();
        if(StringUtils.isNotBlank(wxUser.getNickName())){
            wxUserLambdaQueryWrapper.like(WxUser::getNickName,wxUser.getNickName());
        }
        wxUserLambdaQueryWrapper.orderByDesc(WxUser::getCreateTime);
        Page<WxUser> page=new Page<>(pageNum,pageSize);
        IPage<WxUser> wxUserIPage = wxUserService.page(page,wxUserLambdaQueryWrapper);

        return ResponseBo.ok(wxUserIPage);
    }

    @GetMapping("/list")
    public ResponseBo list(){
        List<WxUser> list = wxUserService.list();
        return ResponseBo.ok(list);

    }


}
