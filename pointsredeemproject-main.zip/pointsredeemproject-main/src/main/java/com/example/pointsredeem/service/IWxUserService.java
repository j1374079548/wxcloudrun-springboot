package com.example.pointsredeem.service;

import com.example.pointsredeem.model.WxUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liya test
 * @since 2026-03-08
 */
public interface IWxUserService extends IService<WxUser> {

}
