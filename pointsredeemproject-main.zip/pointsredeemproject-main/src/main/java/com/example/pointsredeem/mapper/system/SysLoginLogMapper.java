package com.example.pointsredeem.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.pointsredeem.model.system.SysLoginLog;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liya test
 * @since 2023-04-27
 */
public interface SysLoginLogMapper extends BaseMapper<SysLoginLog> {

}
