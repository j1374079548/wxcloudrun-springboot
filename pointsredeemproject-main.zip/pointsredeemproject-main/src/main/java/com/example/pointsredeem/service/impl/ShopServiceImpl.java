package com.example.pointsredeem.service.impl;

import com.example.pointsredeem.model.Shop;
import com.example.pointsredeem.mapper.ShopMapper;
import com.example.pointsredeem.service.IShopService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liya test
 * @since 2026-03-08
 */
@Service
public class ShopServiceImpl extends ServiceImpl<ShopMapper, Shop> implements IShopService {

}
