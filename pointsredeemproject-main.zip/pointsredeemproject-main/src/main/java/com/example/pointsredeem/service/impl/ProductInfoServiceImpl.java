package com.example.pointsredeem.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.pointsredeem.model.ProductInfo;
import com.example.pointsredeem.mapper.ProductInfoMapper;
import com.example.pointsredeem.service.IProductInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 商品信息表（积分兑换专用） 服务实现类
 * </p>
 *
 * @author liya test
 * @since 2026-03-06
 */
@Service
public class ProductInfoServiceImpl extends ServiceImpl<ProductInfoMapper, ProductInfo> implements IProductInfoService {

    @Override
    public IPage<ProductInfo> productList(int pageNum,int pageSize,ProductInfo productInfo) {
        IPage<ProductInfo> page=new Page<>(pageNum,pageSize);
        IPage<ProductInfo> productInfoIPage=baseMapper.productList(page,productInfo);
        return productInfoIPage;
    }
}
