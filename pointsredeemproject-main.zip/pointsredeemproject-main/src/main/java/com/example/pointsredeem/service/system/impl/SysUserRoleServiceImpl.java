package com.example.pointsredeem.service.system.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.pointsredeem.mapper.system.SysUserRoleMapper;
import com.example.pointsredeem.model.system.SysMenu;
import com.example.pointsredeem.model.system.SysUserRole;
import com.example.pointsredeem.service.system.ISysUserRoleService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liya test
 * @since 2023-03-22
 */
@Service
public class SysUserRoleServiceImpl extends ServiceImpl<SysUserRoleMapper, SysUserRole> implements ISysUserRoleService {

    @Override
    public List<SysMenu> getMenu() {
        return null;
    }
}
