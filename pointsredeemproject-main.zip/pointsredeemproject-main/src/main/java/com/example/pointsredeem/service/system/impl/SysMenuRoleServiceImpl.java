package com.example.pointsredeem.service.system.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.pointsredeem.mapper.system.SysMenuRoleMapper;
import com.example.pointsredeem.model.system.SysMenuRole;
import com.example.pointsredeem.service.system.ISysMenuRoleService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liya test
 * @since 2023-03-27
 */
@Service
public class SysMenuRoleServiceImpl extends ServiceImpl<SysMenuRoleMapper, SysMenuRole> implements ISysMenuRoleService {

}
