package com.example.pointsredeem.controller;


import com.example.pointsredeem.common.aspect.ButtonPermission;
import com.example.pointsredeem.common.aspect.Log;
import com.example.pointsredeem.common.pojo.ResponseBo;
import com.example.pointsredeem.service.IAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author liya test
 * @since 2026-03-13
 */
@RestController
@RequestMapping("/address")
public class AddressController {



}
