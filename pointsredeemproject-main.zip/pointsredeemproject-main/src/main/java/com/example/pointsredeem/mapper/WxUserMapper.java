package com.example.pointsredeem.mapper;

import com.example.pointsredeem.model.WxUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liya test
 * @since 2026-03-08
 */
public interface WxUserMapper extends BaseMapper<WxUser> {

}
