package com.example.pointsredeem.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.pointsredeem.model.GivePoints;
import com.example.pointsredeem.mapper.GivePointsMapper;
import com.example.pointsredeem.service.IGivePointsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liya test
 * @since 2026-03-09
 */
@Service
public class GivePointsServiceImpl extends ServiceImpl<GivePointsMapper, GivePoints> implements IGivePointsService {

    @Override
    public IPage<GivePoints> givePointsList(int pageNum, int pageSize, GivePoints givePoints) {
        IPage<GivePoints> page=new Page<>(pageNum,pageSize);
        IPage<GivePoints> givePointsIPage = baseMapper.givePointsList(page, givePoints);
        return givePointsIPage;
    }
}
