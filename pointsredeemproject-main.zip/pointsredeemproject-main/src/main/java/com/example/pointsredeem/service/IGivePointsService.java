package com.example.pointsredeem.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.pointsredeem.model.GivePoints;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liya test
 * @since 2026-03-09
 */
public interface IGivePointsService extends IService<GivePoints> {

    IPage<GivePoints> givePointsList(int pageNum,int pageSize,GivePoints givePoints);

}
