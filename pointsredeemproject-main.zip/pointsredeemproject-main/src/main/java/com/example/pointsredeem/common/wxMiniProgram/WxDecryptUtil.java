package com.example.pointsredeem.common.wxMiniProgram;

import cn.hutool.crypto.Mode;
import cn.hutool.crypto.Padding;
import cn.hutool.crypto.symmetric.AES;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Component;

@Component
public class WxDecryptUtil {

    /**
     * 用code换取session_key和openid
     */
    public JSONObject getSessionKeyAndOpenid(String code) {
        String url = String.format(WxMiniConfig.CODE2SESSION_URL,
                WxMiniConfig.APP_ID, WxMiniConfig.APP_SECRET, code);
        // 调用微信接口
        String result = cn.hutool.http.HttpUtil.get(url);
        JSONObject jsonObject = JSONObject.parseObject(result);

        // 校验错误
        if (jsonObject.containsKey("errcode") && jsonObject.getIntValue("errcode") != 0) {
            throw new RuntimeException("获取sessionKey失败：" + jsonObject.getString("errmsg"));
        }
        return jsonObject;
    }

    /**
     * 解密手机号（修复PKCS7Padding兼容问题）
     */
    public JSONObject decryptData(String encryptedData, String iv, String sessionKey) {
        try {
            // Base64解码
            byte[] encryptedDataBytes = Base64.decodeBase64(encryptedData);
            byte[] ivBytes = Base64.decodeBase64(iv);
            byte[] sessionKeyBytes = Base64.decodeBase64(sessionKey);

            // 核心：兼容PKCS7Padding（用PKCS5Padding替代）
            AES aes = new AES(Mode.CBC, Padding.PKCS5Padding, sessionKeyBytes, ivBytes);
            String decryptStr = aes.decryptStr(encryptedDataBytes);

            // 解析并校验水印（防止数据篡改）
            JSONObject result = JSONObject.parseObject(decryptStr);
            if (!WxMiniConfig.APP_ID.equals(result.getJSONObject("watermark").getString("appid"))) {
                throw new RuntimeException("数据非法，水印校验失败");
            }
            return result;
        } catch (Exception e) {
            throw new RuntimeException("数据解密失败：" + e.getMessage());
        }
    }


    /**
     * 解密用户信息（昵称/头像/性别等）
     */
    public JSONObject decryptUserInfo(String encryptedData, String iv, String sessionKey) {
        return this.decryptData(encryptedData, iv, sessionKey);
    }

    /**
     * 解密手机号
     */
    public String decryptPhoneNumber(String encryptedData, String iv, String sessionKey) {
        JSONObject result = this.decryptData(encryptedData, iv, sessionKey);
        return result.getString("phoneNumber");
    }


}
