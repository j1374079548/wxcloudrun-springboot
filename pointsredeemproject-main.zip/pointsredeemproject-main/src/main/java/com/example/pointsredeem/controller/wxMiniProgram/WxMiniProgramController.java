package com.example.pointsredeem.controller.wxMiniProgram;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.pointsredeem.common.pojo.ResponseBo;
import com.example.pointsredeem.common.util.JwtUtil;
import com.example.pointsredeem.common.wxMiniProgram.WxDecryptUtil;
import com.example.pointsredeem.model.*;
import com.example.pointsredeem.model.wxMini.WxLoginDTO;
import com.example.pointsredeem.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/wx")
public class WxMiniProgramController {

    @Autowired
    private WxDecryptUtil wxDecryptUtil;

    @Autowired
    private IWxUserService wxUserService; // 你的用户业务层
    
    @Autowired
    private IShopCategoryService shopCategoryService;

    @Autowired
    private IProductInfoService productInfoService;

    @Autowired
    private IAddressService addressService;

    /**
     * 合并接口：登录+解密用户信息+手机号
     */
    @PostMapping("/auth/login")
    public ResponseBo login(@RequestBody WxLoginDTO dto) {
        try {
            // 1. 获取session_key
            JSONObject sessionObj = wxDecryptUtil.getSessionKeyAndOpenid(dto.getCode());
            String sessionKey = sessionObj.getString("session_key");
            String openid = sessionObj.getString("openid");

            // 2. 解密手机号
            String phone = wxDecryptUtil.decryptPhoneNumber(dto.getEncryptedData(), dto.getIv(), sessionKey);

            LambdaQueryWrapper<WxUser> wxUserLambdaQueryWrapper=new LambdaQueryWrapper<>();
            wxUserLambdaQueryWrapper.eq(WxUser::getOpenid,openid);
            WxUser wxUser = wxUserService.getOne(wxUserLambdaQueryWrapper);

            String defaultNickname = "微信用户" + phone.substring(phone.length() - 4);
            if(wxUser==null){
                WxUser user=new WxUser();
                user.setPhoneNumber(phone);
                user.setNickName(defaultNickname);
                user.setOpenid(openid);
                wxUserService.save(user);
                String token = JwtUtil.getWxUserToken(user);
                user.setToken(token);
                return ResponseBo.ok(user);
            }else{
                wxUser.setPhoneNumber(phone);
                wxUser.setOpenid(openid);
                wxUser.setNickName(defaultNickname);
                wxUserService.updateById(wxUser);
                String token = JwtUtil.getWxUserToken(wxUser);
                wxUser.setToken(token);
                return ResponseBo.ok(wxUser);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseBo.error("登录失败：" + e.getMessage());
        }
    }


    /**
     * 获取商品分类
     */

    @GetMapping("/categoryList")
    public ResponseBo categoryList(){
        List<ShopCategory> list = shopCategoryService.list();
        return ResponseBo.ok(list);

    }


    /**
     * 通过商品分类id获取商品信息
     */

    @GetMapping("/getProductByCategoryId")
    public ResponseBo getShopByCategoryId(String categoryId){
        LambdaQueryWrapper<ProductInfo> productInfoLambdaQueryWrapper=new LambdaQueryWrapper<>();
        productInfoLambdaQueryWrapper.eq(ProductInfo::getProductCategoryId,categoryId);
        List<ProductInfo> list = productInfoService.list(productInfoLambdaQueryWrapper);
        return ResponseBo.ok(list);

    }

    /**
     * 通过商品id获取商品信息
     */

    @GetMapping("/getProductById")
    public ResponseBo getProductById(String productId){
        ProductInfo productInfo = productInfoService.getById(productId);
        return ResponseBo.ok(productInfo);

    }


    /**
     * 添加收货地址
     * @param address
     * @return
     */
    @PostMapping("/addAddress")
    public ResponseBo add(@RequestBody Address address){
        String currentWxUserId = JwtUtil.getCurrentWxUserId();
        address.setWxUserId(currentWxUserId);
        boolean save = addressService.saveOrUpdate(address);
        if(save){
           return ResponseBo.ok();
        }
        return ResponseBo.error();
    }

    /**
     * 当前登录用户收货地址列表
     * @return
     */
    @GetMapping("/addressList")
    public ResponseBo addressList(){
        String currentWxUserId = JwtUtil.getCurrentWxUserId();
        LambdaQueryWrapper<Address> addressLambdaQueryWrapper=new LambdaQueryWrapper<>();
        addressLambdaQueryWrapper.eq(Address::getWxUserId,currentWxUserId);
        addressLambdaQueryWrapper.orderByAsc(Address::getIsDefault).orderByDesc(Address::getCreateTime);
        List<Address> list = addressService.list(addressLambdaQueryWrapper);
        return ResponseBo.ok(list);

    }

    /**
     * 地址详情
     * @return
     */
    @GetMapping("/addressDetail")
    public ResponseBo addressDetail(String id){

        Address address = addressService.getById(id);
        return ResponseBo.ok(address);

    }
}
