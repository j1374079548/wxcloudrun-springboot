package com.example.pointsredeem.service.system;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.pointsredeem.model.system.SysOperLog;


/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liya test
 * @since 2023-05-04
 */
public interface ISysOperLogService extends IService<SysOperLog> {

}
