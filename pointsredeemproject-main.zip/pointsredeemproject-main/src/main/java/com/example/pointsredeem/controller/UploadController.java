package com.example.pointsredeem.controller;

import com.example.pointsredeem.common.pojo.ResponseBo;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
public class UploadController {

    private final static String baseUrl="http://192.168.101.20:8081";

    @PostMapping("/upload")
    public ResponseBo upload(MultipartFile file) {
        // 对文件判空
        if (file.isEmpty()) {
            return ResponseBo.error("文件为空");
            // 返回一个 R 类型给前端
            // R 为规定数据格式的统一返回对象
        }
        String originalFileName = file.getOriginalFilename();
        // ↑ 获取文件的名称
        String fileName = System.currentTimeMillis() + "." + originalFileName.substring(originalFileName.lastIndexOf(".") + 1);
        // ↑ 以当前时间戳对文件进行重命名，并保存文件名后缀
        String filePath = "D:/home/demo/tempdownload/";
        // ↑ 设定文件的所要上传的服务器路径
        File dist = new File(filePath + fileName);

        // ↓ 对文件路径判空
        if (!dist.getParentFile().exists()) {
            dist.getParentFile().mkdirs();
            // ↑ 若文件路径不存在则创建
        }
        try {
            // ↓ 上传文件
            file.transferTo(dist);
            return ResponseBo.ok(0,"上传成功",fileName);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseBo.error("上传失败");
        }

    }


    @PostMapping("/wangEditorUpload")
    public Map<String, Object> wangEditorUpload(MultipartFile file) {
        // 对文件判空
        if (file.isEmpty()) {
            return ResponseBo.error("文件为空");
            // 返回一个 R 类型给前端
            // R 为规定数据格式的统一返回对象
        }
        String originalFileName = file.getOriginalFilename();
        // ↑ 获取文件的名称
        String fileName = System.currentTimeMillis() + "." + originalFileName.substring(originalFileName.lastIndexOf(".") + 1);
        // ↑ 以当前时间戳对文件进行重命名，并保存文件名后缀
        String filePath = "D:/home/demo/tempdownload/";
        // ↑ 设定文件的所要上传的服务器路径
        File dist = new File(filePath + fileName);

        // ↓ 对文件路径判空
        if (!dist.getParentFile().exists()) {
            dist.getParentFile().mkdirs();
            // ↑ 若文件路径不存在则创建
        }
        Map<String, Object> result = new HashMap<>();
        try {
            // ↓ 上传文件
            file.transferTo(dist);

            result.put("errno", 0);
            result.put("data", new String[]{baseUrl+"/download/"+fileName});
            result.put("message", "上传成功");
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseBo.error("上传失败");
        }

    }


    /**
     * 文件下载
     * @param name
     * @param response
     */
    @GetMapping("/download/{name}")
    public void download(@PathVariable("name")String name, HttpServletResponse response){
        String filePath = "D:/home/demo/tempdownload/";
        File file = new File(filePath + name);

        // 1. 先判断文件是否存在
        if (!file.exists()) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        // 2. 设置响应头（告诉浏览器/小程序这是图片）
        String contentType = getContentType(name);
        response.setContentType(contentType);
        response.setHeader("Content-Disposition", "filename=" + name);

        try (FileInputStream fileInputStream = new FileInputStream(file);
             ServletOutputStream outputStream = response.getOutputStream()) {

            byte[] bytes = new byte[1024];
            int len;
            while ((len = fileInputStream.read(bytes)) != -1) {
                outputStream.write(bytes, 0, len);
            }
            outputStream.flush();
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    // 辅助方法：根据文件名后缀获取 Content-Type
    private String getContentType(String fileName) {
        if (fileName.endsWith(".png")) return "image/png";
        if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) return "image/jpeg";
        if (fileName.endsWith(".gif")) return "image/gif";
        if (fileName.endsWith(".webp")) return "image/webp";
        return "application/octet-stream"; // 默认二进制流
    }

    // 处理中文文件名编码问题‌:ml-citation{ref="8" data="citationList"}
    private String encodeFileName(String name) throws UnsupportedEncodingException {
        return new String(name.getBytes("GBK"), "ISO-8859-1");
    }

    /**
     * 上传获取文件流
     * @param file
     * @return
     */
    @PostMapping("/upload1")
    public ResponseBo upload1(MultipartFile file) throws IOException {
        // 对文件判空
        if (file.isEmpty()) {
            return ResponseBo.error("文件为空");
            // 返回一个 R 类型给前端
            // R 为规定数据格式的统一返回对象
        }
        String originalFileName = file.getOriginalFilename();
        // ↑ 获取文件的名称
        String fileName = System.currentTimeMillis() + "." + originalFileName.substring(originalFileName.lastIndexOf(".") + 1);
        // ↑ 以当前时间戳对文件进行重命名，并保存文件名后缀
        String filePath = "D:/home/demo/tempdownload/";
        // ↑ 设定文件的所要上传的服务器路径
        File dist = new File(filePath + fileName);

        // ↓ 对文件路径判空
        if (!dist.getParentFile().exists()) {
            dist.getParentFile().mkdirs();
            // ↑ 若文件路径不存在则创建
        }
        try {
            // ↓ 上传文件
            file.transferTo(dist);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseBo.error("上传失败");
        }

        FileInputStream inputstream = new FileInputStream(new File(filePath+fileName));
        byte[] byt= IOUtils.toByteArray(inputstream);
        return ResponseBo.ok(0,"上传成功",byt);
    }


}
