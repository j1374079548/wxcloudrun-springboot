package com.example.pointsredeem.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.pointsredeem.common.captcha.CaptchaUtil;
import com.example.pointsredeem.common.pojo.ResponseBo;
import com.example.pointsredeem.common.redis.RedisUtil;
import com.example.pointsredeem.common.util.IpUtil;
import com.example.pointsredeem.common.util.JwtUtil;
import com.example.pointsredeem.common.util.MD5Utils;

import com.example.pointsredeem.model.system.SysLoginLog;
import com.example.pointsredeem.model.system.SysMenu;
import com.example.pointsredeem.model.system.SysUser;
import com.example.pointsredeem.service.system.ISysLoginLogService;
import com.example.pointsredeem.service.system.ISysMenuService;
import com.example.pointsredeem.service.system.ISysUserService;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.*;

@RestController
public class LoginController {

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private ISysMenuService sysMenuService;

    @Autowired
    private ISysLoginLogService sysLoginLogService;



    @Autowired
    private RedisUtil redisUtil;

    private static final long captchaExpireTime=120;


    @GetMapping("/generateCaptcha")
    public ResponseBo generateCaptcha()  {

        String captchaText=CaptchaUtil.createText();
        // 2. 生成验证码唯一标识
        String captchaKey = "captcha:" + UUID.randomUUID().toString().replace("-", "");
        // 3. 存入Redis
        redisUtil.setWithExpire(captchaKey, captchaText, captchaExpireTime);
        // 4. 生成验证码图片并转为Base64
        BufferedImage image = CaptchaUtil.createImage(captchaText);


        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            ImageIO.write(image, "jpg", outputStream);
            String base64Image = "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(outputStream.toByteArray());
            // 5. 返回结果
            Map<String, String> result = new HashMap<>();
            result.put("captchaText",captchaText);
            result.put("captchaKey", captchaKey);
            result.put("captchaImage", base64Image);
            return ResponseBo.ok(result);
        } catch (Exception e) {
//            return ResponseBo.error("验证码生成失败");
            throw new RuntimeException("验证码生成失败");
        }
    }

    @PostMapping("/login")
    public ResponseBo login(@RequestBody SysUser user, HttpServletRequest request) {
        String jcaptcha = redisUtil.get(user.getCaptchaKey());
        if(StringUtils.isBlank(jcaptcha)){
            return ResponseBo.error("验证码已过期！");

        }else if (!CaptchaUtil.verifyResult(user.getCaptcha())) {
            return ResponseBo.error("验证码不正确！");
        }
        String username= user.getUsername();
        SysUser sysUser = sysUserService.findByUserName1(username);
        if(sysUser==null){
            return ResponseBo.error("该用户不存在，请核实！");
        }
        SysLoginLog loginLog=new SysLoginLog();
        loginLog.setLoginUserName(sysUser.getUsername());
        loginLog.setIpAddress(IpUtil.getIpAddr(request));
        if ("1".equals(sysUser.getStatus())) {
            String password=user.getPassword();
            //将用户名密码加密
            String mde5Password = MD5Utils.encrypt(password);
            //shiro令牌
            UsernamePasswordToken token = new UsernamePasswordToken(username, mde5Password);
            Subject subject = SecurityUtils.getSubject();
            try {
                subject.login(token);
                String token1 = JwtUtil.getToken(sysUser);
                sysUser.setToken(token1);
                loginLog.setLoginStatus("0");
                sysLoginLogService.save(loginLog);
                return ResponseBo.ok(0,"登录成功",sysUser);
            } catch (UnknownAccountException e) {
                loginLog.setLoginStatus("1");
                sysLoginLogService.save(loginLog);
                return ResponseBo.error(e.getMessage());
            } catch (IncorrectCredentialsException e) {
                loginLog.setLoginStatus("1");
                sysLoginLogService.save(loginLog);
                return ResponseBo.error(e.getMessage());
            } catch (LockedAccountException e) {
                loginLog.setLoginStatus("1");
                sysLoginLogService.save(loginLog);
                return ResponseBo.error(e.getMessage());
            } catch (AuthenticationException e) {
                loginLog.setLoginStatus("1");
                sysLoginLogService.save(loginLog);
                return ResponseBo.error("认证失败！");
            }

        }else{
            return ResponseBo.error("该账号已禁用，请联系管理员！");
        }
    }

    /**
     * 菜单权限
     * @return
     */
    @GetMapping("/leftMenu")
    public ResponseBo leftMenu(){
        List<SysMenu> sysMenus = sysMenuService.leftMenu();
        return ResponseBo.ok(sysMenus);
    }
    /**
     * 按钮权限
     * @return
     */
    @GetMapping("butPermission")
    public ResponseBo butPermission(String menuId){
        List<SysMenu> butPermission = sysMenuService.getButPermission(menuId);
        return ResponseBo.ok(butPermission);
    }


    /**
     * 首页学生人数查询
     * @return
     */
    @GetMapping("userStatistics")
    public ResponseBo userStatistics(){
        return ResponseBo.ok();
    }


    @GetMapping("overallStatistics")
    public ResponseBo overallStatistics(){


        return ResponseBo.ok();
    }
}
