package com.example.pointsredeem.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.pointsredeem.common.ProductCodeGenerator;
import com.example.pointsredeem.common.aspect.ButtonPermission;
import com.example.pointsredeem.common.aspect.Log;
import com.example.pointsredeem.common.pojo.ResponseBo;
import com.example.pointsredeem.model.ProductInfo;
import com.example.pointsredeem.model.Shop;
import com.example.pointsredeem.model.ShopCategory;
import com.example.pointsredeem.model.system.SysDictionary;
import com.example.pointsredeem.service.IShopService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author liya test
 * @since 2026-03-08
 */
@RestController
@RequestMapping("/shop")
public class ShopController {


    @Autowired
    private IShopService shopService;

    @GetMapping("/page")
    public ResponseBo page(int pageNum, int pageSize, Shop shop) {
        IPage<Shop> page=new Page<>(pageNum,pageSize);
        LambdaQueryWrapper<Shop> shopLambdaQueryWrapper=new LambdaQueryWrapper<>();
        if (StringUtils.isNotBlank(shop.getShopName())) {
            shopLambdaQueryWrapper.like(Shop::getShopName,shop.getShopName());
        }
        shopLambdaQueryWrapper.orderByDesc(Shop::getCreateTime);
        IPage<Shop> shopIPage = shopService.page(page, shopLambdaQueryWrapper);
        return ResponseBo.ok(shopIPage);
    }

    @GetMapping("/view")
    public ResponseBo view(String id) {
        Shop shop = shopService.getById(id);

        return ResponseBo.ok(shop);
    }


    @GetMapping("/del")
    @Log(title = "删除经销商")
    @ButtonPermission(perm = "shop:del")
    public ResponseBo del(String id) {
        boolean remove = shopService.removeById(id);
        if(remove){
            return ResponseBo.ok();
        }
        return ResponseBo.error();

    }


    @PostMapping("/add")
    @Log(title = "添加经销商")
    @ButtonPermission(perm = "shop:add")
    public ResponseBo add(@RequestBody Shop shop) {

        boolean save = shopService.save(shop);
        if(save){
            return ResponseBo.ok();
        }
        return ResponseBo.error();
    }

    @PostMapping("/edit")
    @Log(title = "修改经销商")
    @ButtonPermission(perm = "shop:edit")
    public ResponseBo edit(@RequestBody Shop shop) {

        boolean update = shopService.updateById(shop);
        if(update){
            return ResponseBo.ok();
        }
        return ResponseBo.error();
    }

    @GetMapping("/list")
    public ResponseBo list() {
        List<Shop> shopList = shopService.list();

        return ResponseBo.ok(shopList);
    }
}
