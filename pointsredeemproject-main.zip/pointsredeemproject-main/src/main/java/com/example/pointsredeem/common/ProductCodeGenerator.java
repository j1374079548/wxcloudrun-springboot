package com.example.pointsredeem.common;

import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class ProductCodeGenerator {

    // 存储「日期+前缀」对应的序列号（避免不同日期/前缀序列号重复）
    private static final ConcurrentHashMap<String, AtomicInteger> seqMap = new ConcurrentHashMap<>();

    // 默认配置
    private static final String DEFAULT_PREFIX = "PROD"; // 默认前缀
    private static final String DATE_FORMAT = "yyyyMMdd"; // 日期格式
    private static final int SEQ_LENGTH = 4; // 序列号长度（不足补0）

    /**
     * 生成默认格式商品编号（PROD+日期+4位序列号）
     */
    public static String generateCode() {
        return generateCode(DEFAULT_PREFIX);
    }

    /**
     * 自定义前缀生成商品编号
     */
    public static String generateCode(String prefix) {
        // 1. 获取当日日期字符串（yyyyMMdd）
        String dateStr = new SimpleDateFormat(DATE_FORMAT).format(new Date());
        // 2. 构建key（前缀+日期），隔离不同前缀/日期的序列号
        String key = prefix + "_" + dateStr;
        // 3. 获取/初始化当日序列号（原子类保证线程安全）
        AtomicInteger seq = seqMap.computeIfAbsent(key, k -> new AtomicInteger(1));
        int currentSeq = seq.getAndIncrement();
        // 4. 序列号补0（如1→0001）
        String seqStr = String.format("%0" + SEQ_LENGTH + "d", currentSeq);
        // 5. 拼接最终编号（去掉分隔符，便于存储和传输）
        return prefix + dateStr + seqStr;
    }

    /**
     * 带分类的商品编号生成（如 PROD-SM-202603070001）
     */
    public String generateCodeWithCategory(String prefix, String categoryShortCode) {
        String dateStr = new SimpleDateFormat(DATE_FORMAT).format(new Date());
        String key = prefix + "_" + categoryShortCode + "_" + dateStr;
        AtomicInteger seq = seqMap.computeIfAbsent(key, k -> new AtomicInteger(1));
        int currentSeq = seq.getAndIncrement();
        String seqStr = String.format("%0" + SEQ_LENGTH + "d", currentSeq);
        return prefix + "-" + categoryShortCode + "-" + dateStr + seqStr;
    }

    /**
     * 重置当日序列号（仅测试/异常恢复时使用）
     */
    public void resetSeq(String prefix) {
        String dateStr = new SimpleDateFormat(DATE_FORMAT).format(new Date());
        String key = prefix + "_" + dateStr;
        seqMap.put(key, new AtomicInteger(1));
    }
}
