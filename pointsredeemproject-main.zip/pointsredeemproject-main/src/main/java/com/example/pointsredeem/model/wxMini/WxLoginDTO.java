package com.example.pointsredeem.model.wxMini;

import lombok.Data;

/**
 * 接收前端传递的参数
 */
@Data
public class WxLoginDTO {
    private String code; // 微信login的code
    private String encryptedData; // 手机号加密数据
    private String iv; // 加密初始向量
}
