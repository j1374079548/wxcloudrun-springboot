package com.example.pointsredeem.controller.system;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.pointsredeem.common.aspect.ButtonPermission;
import com.example.pointsredeem.common.aspect.Log;
import com.example.pointsredeem.common.pojo.ResponseBo;
import com.example.pointsredeem.common.util.MD5Utils;
import com.example.pointsredeem.model.system.SysDictionary;
import com.example.pointsredeem.model.system.SysUser;
import com.example.pointsredeem.service.system.ISysDictionaryService;
import com.example.pointsredeem.service.system.ISysUserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author liya test
 * @since 2023-03-15
 */
@RestController
@RequestMapping("/system/user")
public class SysUserController {

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private ISysDictionaryService sysDictionaryService;


    /**
     * 分页
     * @param pageNum
     * @param pageSize
     * @return
     */
    @GetMapping("/page")
    public ResponseBo page(int pageNum,int pageSize,SysUser sysUser){
        IPage<SysUser> page = sysUserService.getPage(pageNum, pageSize,sysUser);
        return ResponseBo.ok(page);
    }

    /**
     * 添加
     * @param sysUser
     * @return
     */
    @PostMapping("/add")
    @ButtonPermission(perm = "sys:user:add")
    @Log(title = "系统用户:添加用户")
    public ResponseBo add(@RequestBody SysUser sysUser){
        SysUser byUserName = sysUserService.findByUserName(sysUser.getUsername());
        if(byUserName!=null){
            return ResponseBo.error("该用户名已存在！");
        }
        sysUser.setPassword("123456");
        sysUser.setPassword(MD5Utils.encrypt(sysUser.getPassword()));
        boolean save = sysUserService.add(sysUser);
        if(save){
            return ResponseBo.ok("添加成功");
        }else{
            return ResponseBo.error("添加失败");
        }
    }


    /**
     * 编辑
     * @param sysUser
     * @return
     */
    @PostMapping("/edit")
    @ButtonPermission(perm = "sys:user:edit")
    @Log(title = "系统用户:修改用户")
    public ResponseBo edit(@RequestBody SysUser sysUser){
        SysUser byUserName = sysUserService.findByUserName(sysUser.getUsername());
        if(byUserName!=null&&!byUserName.getId().equals(sysUser.getId())){
            return ResponseBo.error("该用户名已存在！");
        }
        if(StringUtils.isNotBlank(sysUser.getPassword())){
            sysUser.setPassword(MD5Utils.encrypt(sysUser.getPassword()));
        }

        boolean save = sysUserService.edit(sysUser);
        if(save){
            return ResponseBo.ok("修改成功");
        }else{
            return ResponseBo.error("修改失败");
        }
    }

    /**
     * 详情
     * @param id
     * @return
     */
    @GetMapping("/one")
//    @ButtonPermission(perm = "sys:user:view")
    public ResponseBo one(String id){
        if(StringUtils.isNotBlank(id)){
            SysUser one = sysUserService.one(id);
            return ResponseBo.ok(one);
        }else{
            return ResponseBo.error("查询失败");
        }
    }

    /**
     * 删除
     * @param id
     * @return
     */
    @GetMapping("/del")
    @Log(title = "系统用户:删除用户")
    public ResponseBo del(String id){
        if(StringUtils.isNotBlank(id)){
            boolean del = sysUserService.del(id);
            if(del){
                return ResponseBo.ok("删除成功");
            }else{
                return ResponseBo.error("删除失败");
            }
        }else{
            return ResponseBo.error("删除失败");
        }
    }

    @GetMapping("/rest")
    @Log(title = "系统用户:重置密码")
    public ResponseBo rest(String id){
        if(StringUtils.isNotBlank(id)){
            LambdaUpdateWrapper<SysUser> sysUserLambdaUpdateWrapper=new LambdaUpdateWrapper<>();
            sysUserLambdaUpdateWrapper.eq(SysUser::getId,id);
            sysUserLambdaUpdateWrapper.set(SysUser::getPassword,MD5Utils.encrypt("123456"));
            boolean update = sysUserService.update(sysUserLambdaUpdateWrapper);
            if(update){
                return ResponseBo.ok();
            }else{
                return ResponseBo.error();
            }
        }else{
            return ResponseBo.error();
        }
    }

    /**
     * 导出
     * @return
     */
    @GetMapping("/export")
    @ButtonPermission(perm = "sys:user:export")
    public void export(HttpServletResponse response) throws IOException {
        SysUser sysUser=new SysUser();
         sysUserService.exportList(response,sysUser);
    }
}
