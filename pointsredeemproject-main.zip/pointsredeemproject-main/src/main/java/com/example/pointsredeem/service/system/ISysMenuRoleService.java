package com.example.pointsredeem.service.system;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.pointsredeem.model.system.SysMenuRole;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liya test
 * @since 2023-03-27
 */
public interface ISysMenuRoleService extends IService<SysMenuRole> {

}
