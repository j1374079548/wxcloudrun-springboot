package com.example.pointsredeem.service.impl;

import com.example.pointsredeem.model.Address;
import com.example.pointsredeem.mapper.AddressMapper;
import com.example.pointsredeem.service.IAddressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liya test
 * @since 2026-03-13
 */
@Service
public class AddressServiceImpl extends ServiceImpl<AddressMapper, Address> implements IAddressService {

}
