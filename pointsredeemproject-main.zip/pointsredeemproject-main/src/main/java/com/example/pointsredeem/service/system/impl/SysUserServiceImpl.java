package com.example.pointsredeem.service.system.impl;


import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.enmus.ExcelType;
import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.pointsredeem.mapper.system.SysUserMapper;
import com.example.pointsredeem.model.Shop;
import com.example.pointsredeem.model.ShopCategory;
import com.example.pointsredeem.model.system.*;
import com.example.pointsredeem.service.IShopService;
import com.example.pointsredeem.service.system.ISysRoleService;
import com.example.pointsredeem.service.system.ISysUserRoleService;
import com.example.pointsredeem.service.system.ISysUserService;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liya test
 * @since 2023-03-15
 */
@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements ISysUserService {

    @Autowired
    private ISysUserRoleService sysUserRoleService;

    @Autowired
    private ISysRoleService sysRoleService;

    @Autowired
    private IShopService shopService;



    @Override
    public SysUser findByUserName(String userName) {
        LambdaQueryWrapper<SysUser> userLambdaQueryWrapper=new LambdaQueryWrapper<>();
        userLambdaQueryWrapper.eq(SysUser::getUsername,userName).eq(SysUser::getStatus,"1");
        return baseMapper.selectOne(userLambdaQueryWrapper);
    }

    public SysUser findByUserName1(String userName) {
        LambdaQueryWrapper<SysUser> userLambdaQueryWrapper=new LambdaQueryWrapper<>();
        userLambdaQueryWrapper.eq(SysUser::getUsername,userName);
        return baseMapper.selectOne(userLambdaQueryWrapper);
    }

    @Override
    public IPage<SysUser> getPage(int pageNum, int pageSize,SysUser sysUser) {
        IPage<SysUser> page=new Page<>(pageNum,pageSize);
        IPage<SysUser> userIPage = baseMapper.userPage(page, sysUser);
        return userIPage;
    }

    @Override
    @Transactional
    public boolean edit(SysUser sysUser) {
        LambdaQueryWrapper<SysUserRole> userRoleLambdaQueryWrapper=new LambdaQueryWrapper<>();
        userRoleLambdaQueryWrapper.eq(SysUserRole::getUserId,sysUser.getId());
        sysUserRoleService.getBaseMapper().delete(userRoleLambdaQueryWrapper);
        int i = baseMapper.updateById(sysUser);

//        if(sysUser.getRoleIds()!=null){
//            for (String roleId:sysUser.getRoleIds()){
//                SysUserRole userRole=new SysUserRole();
//                userRole.setUserId(sysUser.getId());
//                userRole.setRoleId(roleId);
//                sysUserRoleService.save(userRole);
//
//            }
//        }

        if (StringUtils.isNotBlank(sysUser.getRoleId())) {
            SysUserRole userRole=new SysUserRole();
            userRole.setUserId(sysUser.getId());
            userRole.setRoleId(sysUser.getRoleId());
            sysUserRoleService.save(userRole);
        }
        if(i==0){
            return false;
        }else{
            return true;
        }
    }

    @Override
    @Transactional
    public boolean add(SysUser sysUser) {
        int insert = baseMapper.insert(sysUser);

        if (StringUtils.isNotBlank(sysUser.getRoleId())) {
            SysUserRole userRole=new SysUserRole();
            userRole.setUserId(sysUser.getId());
            userRole.setRoleId(sysUser.getRoleId());
            sysUserRoleService.save(userRole);
        }
//        for (String roleId:sysUser.getRoleIds()){
//            SysUserRole userRole=new SysUserRole();
//            userRole.setUserId(sysUser.getId());
//            userRole.setRoleId(roleId);
//            sysUserRoleService.save(userRole);
//
//        }
        if(insert==0){
            return false;
        }else{
            return true;
        }
    }

    @Override
    public SysUser one(String id) {
        SysUser sysUser = baseMapper.selectById(id);
        LambdaQueryWrapper<SysUserRole> userRoleLambdaQueryWrapper=new LambdaQueryWrapper<>();
        userRoleLambdaQueryWrapper.eq(SysUserRole::getUserId,id);
//        List<SysUserRole> list = sysUserRoleService.list(userRoleLambdaQueryWrapper);
//        String[] roleArray=list.stream().map(sysUserRole -> sysUserRole.getRoleId()).toArray(String[]::new);
//        if(roleArray.length!=0){
//            List<SysRole> sysRoles = sysRoleService.getBaseMapper().selectBatchIds(Arrays.asList(roleArray));
//            String roleNames = sysRoles.stream().map(role -> role.getRoleName()).collect(Collectors.joining("，"));
//            sysUser.setRoleNames(roleNames);
//            sysUser.setRoleIds(roleArray);
//        }
        SysUserRole userRole = sysUserRoleService.getOne(userRoleLambdaQueryWrapper);
        SysRole sysRole = sysRoleService.getBaseMapper().selectById(userRole.getRoleId());
        sysUser.setRoleName(sysRole.getRoleName());
        sysUser.setRoleId(sysRole.getId());
        return sysUser;
    }

    @Override
    public boolean del(String id) {
        int i = baseMapper.deleteById(id);
        if(i==1){
            LambdaQueryWrapper<SysUserRole> userRoleLambdaQueryWrapper=new LambdaQueryWrapper<>();
            userRoleLambdaQueryWrapper.eq(SysUserRole::getUserId,id);
            sysUserRoleService.remove(userRoleLambdaQueryWrapper);
        }
        if(i==0){
            return false;
        }else {
            return true;
        }
    }

    @Override
    public String selectNameBatchIds(String[] idList) {
        return baseMapper.selectNameBatchIds(idList);
    }


    @Override
    public void exportList(HttpServletResponse response,SysUser sysUser) throws IOException {
        List<SysUser> sysUserList = baseMapper.userList(sysUser);
        List<SysUserExcel> sysUserExcelList = BeanUtil.copyToList(sysUserList, SysUserExcel.class);
        response.setCharacterEncoding("UTF-8");
        response.setHeader("content-Type", "application/vnd.ms-excel");
        response.setHeader("Content-Disposition",
                "attachment;filename=" + URLEncoder.encode("系统用户.xlx", "UTF-8"));

        ServletOutputStream out = response.getOutputStream();

        //设置excel参数
        ExportParams params = new ExportParams();
        //设置sheet名名称
        params.setSheetName("系统用户");
        //设置标题
        params.setTitle("系统用户信息表");

        params.setType(ExcelType.XSSF);

        Workbook workbook = ExcelExportUtil.exportExcel(params, SysUserExcel.class, sysUserExcelList);
        workbook.write(out);
    }



}
