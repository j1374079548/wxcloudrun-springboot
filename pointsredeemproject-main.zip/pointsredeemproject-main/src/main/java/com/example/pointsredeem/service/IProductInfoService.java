package com.example.pointsredeem.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.pointsredeem.model.ProductInfo;
import com.baomidou.mybatisplus.extension.service.IService;


import java.util.List;

/**
 * <p>
 * 商品信息表（积分兑换专用） 服务类
 * </p>
 *
 * @author liya test
 * @since 2026-03-06
 */
public interface IProductInfoService extends IService<ProductInfo> {

    IPage<ProductInfo> productList(int pageNum, int pageSize, ProductInfo productInfo);


}
