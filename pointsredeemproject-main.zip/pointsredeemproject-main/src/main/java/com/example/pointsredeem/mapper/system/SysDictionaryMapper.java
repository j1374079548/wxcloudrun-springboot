package com.example.pointsredeem.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.pointsredeem.model.system.SysDictionary;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liya test
 * @since 2023-04-25
 */
public interface SysDictionaryMapper extends BaseMapper<SysDictionary> {

}
