package com.example.pointsredeem.service.system;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.pointsredeem.model.system.SysMenu;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liya test
 * @since 2023-03-22
 */
public interface ISysMenuService extends IService<SysMenu> {

    IPage<SysMenu> getPage(int pageNum,int pageSize);

    List<SysMenu> leftMenu();

    List<SysMenu> getButPermission(String menuId);

    int del(String id);

    int add(SysMenu sysMenu);

    int edit(SysMenu sysMenu);

    SysMenu one(String id);

}
