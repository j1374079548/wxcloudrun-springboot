package com.example.pointsredeem.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.pointsredeem.model.GivePoints;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liya test
 * @since 2026-03-09
 */
public interface GivePointsMapper extends BaseMapper<GivePoints> {

    IPage<GivePoints> givePointsList(@Param("page") IPage page, @Param("points") GivePoints givePoints);

}
