package com.example.pointsredeem.common.wxMiniProgram;

import org.springframework.stereotype.Component;

@Component
public class WxMiniConfig {

    // 替换为你的小程序AppID
    public static final String APP_ID = "wx487b34b5ebaae2a9";
    // 替换为你的小程序AppSecret
    public static final String APP_SECRET = "1356d3d5885fd22afea3978151d48979";
    // 微信获取session_key的接口
    public static final String CODE2SESSION_URL = "https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code";
}
