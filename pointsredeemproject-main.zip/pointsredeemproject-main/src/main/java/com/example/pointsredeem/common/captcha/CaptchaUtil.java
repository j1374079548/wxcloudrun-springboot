package com.example.pointsredeem.common.captcha;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 * 登录验证码生成工具类
 */
public class CaptchaUtil {
    // 验证码图片宽度
    private static final int WIDTH = 150;
    // 验证码图片高度
    private static final int HEIGHT = 40;
    // 验证码长度（运算式：数字+运算符+数字）
    private static final int CODE_LENGTH = 3;
    // 运算数字范围
    private static final int NUM_MIN = 1;
    private static final int NUM_MAX = 10;
    // 运算符号
    private static final char[] OPERATORS = {'+', '-', '*', '÷'};
    // 随机对象
    private static final Random random = new Random();
    // 运算结果（用于验证）
    private static int captchaResult;


    /**
     * 生成验证码图片（含运算式）
     */
    public static BufferedImage createImage(String code) {
        BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();

        // 1. 填充背景
        g2d.setColor(new Color(245, 245, 245));
        g2d.fillRect(0, 0, WIDTH, HEIGHT);

        // 2. 绘制干扰元素
//        drawInterference(g2d);

        // 3. 设置字体
        setCaptchaFont(g2d);

        // 4. 绘制运算式文本
        drawCodeText(g2d, code);

        g2d.dispose();
        return image;
    }


    /**
     * 设置验证码字体
     */
    private static void setCaptchaFont(Graphics2D g2d) {
        String[] fontNames = {"Arial", "Verdana", "Courier New", "SimHei", "Microsoft YaHei"};
        int fontSize = (int) (HEIGHT * 0.7);
        Font font = new Font(fontNames[random.nextInt(fontNames.length)], Font.BOLD, fontSize);
        g2d.setFont(font);
    }


    /**
     * 生成运算式验证码文本
     */
    public static String createText() {
        StringBuilder sb = new StringBuilder();
        // 第一个数字
        int num1 = NUM_MIN + random.nextInt(NUM_MAX - NUM_MIN + 1);
        // 运算符号
        char op = OPERATORS[random.nextInt(OPERATORS.length)];
        // 第二个数字（根据运算符适配）
        int num2;
        switch (op) {
            case '-':
                // 减法：避免结果为负
                num2 = NUM_MIN + random.nextInt(num1 - NUM_MIN + 1);
                break;
            case '*':
                // 乘法：避免结果过大
                num2 = NUM_MIN + random.nextInt(5);
                break;
            case '÷':
                // 除法：保证num1是num2的倍数（结果为整数）
                num2 = NUM_MIN + random.nextInt(5); // 除数范围1-5
                num1 = num2 * (NUM_MIN + random.nextInt(5)); // 被除数 = 除数 × 随机数（1-5）
                break;
            default: // '+'
                num2 = NUM_MIN + random.nextInt(NUM_MAX - NUM_MIN + 1);
                break;
        }
        // 拼接运算式
        sb.append(num1).append(op).append(num2);
        // 计算结果
        captchaResult = calculate(num1, op, num2);
        return sb.toString();
    }


    /**
     * 计算运算结果
     */
    private static int calculate(int num1, char op, int num2) {
        switch (op) {
            case '+': return num1 + num2;
            case '-': return num1 - num2;
            case '*': return num1 * num2;
            case '÷': return num1 / num2; // 除法（已保证是整数）
            default: return 0;
        }
    }


    /**
     * 验证用户输入的结果
     */
    public static boolean verifyResult(int input) {
        return input == captchaResult;
    }


    /**
     * 绘制干扰线和噪点
     */
    private static void drawInterference(Graphics2D g2d) {
        // 干扰线
        g2d.setColor(new Color(random.nextInt(200), random.nextInt(200), random.nextInt(200)));
        for (int i = 0; i < 6; i++) {
            int x1 = random.nextInt(WIDTH);
            int y1 = random.nextInt(HEIGHT);
            int x2 = random.nextInt(WIDTH);
            int y2 = random.nextInt(HEIGHT);
            g2d.drawLine(x1, y1, x2, y2);
        }
        // 噪点
        for (int i = 0; i < 100; i++) {
            g2d.fillRect(random.nextInt(WIDTH), random.nextInt(HEIGHT), 2, 2);
        }
    }


    /**
     * 绘制运算式文本
     */
    private static void drawCodeText(Graphics2D g2d, String code) {
        // 新的字符间距：(宽度-20) ÷ 字符长度（运算式可能是4位，比如“10÷2”）
        int charSpacing = (WIDTH - 30) / code.length(); // 减30让两边留空更充足
        for (int i = 0; i < code.length(); i++) {
            g2d.setColor(new Color(20 + random.nextInt(120), 20 + random.nextInt(120), 20 + random.nextInt(120)));
            int angle = random.nextInt(40) - 20;
            g2d.rotate(Math.toRadians(angle), 20 + i * charSpacing, HEIGHT / 2); // 左边留空20，避免顶边
            g2d.drawString(String.valueOf(code.charAt(i)), 20 + i * charSpacing, HEIGHT / 2 + g2d.getFont().getSize() / 4);
            g2d.rotate(-Math.toRadians(angle), 20 + i * charSpacing, HEIGHT / 2);
        }
    }
}