package com.example.pointsredeem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PointsRedeemProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
